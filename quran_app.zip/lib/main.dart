import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const QuranApp());

class Surah {
  final int id;
  final String name;
  final String arabicName;
  final String englishName;
  final String audioUrl;

  const Surah({
    required this.id,
    required this.name,
    required this.arabicName,
    required this.englishName,
    required this.audioUrl,
  });

  factory Surah.fromJson(Map<String, dynamic> json) {
    return Surah(
      id: json['id'],
      name: json['name'],
      arabicName: json['arabicName'],
      englishName: json['englishName'],
      audioUrl: json['audioUrl'],
    );
  }
}

class QuranApp extends StatelessWidget {
  const QuranApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quran App',
      theme: ThemeData.dark().copyWith(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<Surah> _surahs = [];
  List<Surah> _filteredSurahs = [];
  String searchText = "";
  int? _currentlyPlayingId;
  bool _isPlaying = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSurahData();
  }

  void _loadSurahData() {
    final jsonData = '''
    [
      {"id":1,"name":"Al-Fatiha","arabicName":"الفاتحة","englishName":"The Opening","audioUrl":"https://server8.mp3quran.net/afs/001.mp3"},
      {"id":2,"name":"Al-Baqarah","arabicName":"البقرة","englishName":"The Cow","audioUrl":"https://server8.mp3quran.net/afs/002.mp3"},
      {"id":3,"name":"Aal-E-Imran","arabicName":"آل عمران","englishName":"Family of Imran","audioUrl":"https://server8.mp3quran.net/afs/003.mp3"},
      {"id":4,"name":"An-Nisa","arabicName":"النساء","englishName":"The Women","audioUrl":"https://server8.mp3quran.net/afs/004.mp3"},
      {"id":5,"name":"Al-Ma'idah","arabicName":"المائدة","englishName":"The Table","audioUrl":"https://server8.mp3quran.net/afs/005.mp3"},
      {"id":6,"name":"Al-An'am","arabicName":"الأنعام","englishName":"The Cattle","audioUrl":"https://server8.mp3quran.net/afs/006.mp3"},
      {"id":7,"name":"Al-A'raf","arabicName":"الأعراف","englishName":"The Heights","audioUrl":"https://server8.mp3quran.net/afs/007.mp3"},
      {"id":8,"name":"Al-Anfal","arabicName":"الأنفال","englishName":"The Spoils of War","audioUrl":"https://server8.mp3quran.net/afs/008.mp3"},
      {"id":9,"name":"At-Tawbah","arabicName":"التوبة","englishName":"The Repentance","audioUrl":"https://server8.mp3quran.net/afs/009.mp3"},
      {"id":10,"name":"Yunus","arabicName":"يونس","englishName":"Jonah","audioUrl":"https://server8.mp3quran.net/afs/010.mp3"},
      {"id":11,"name":"Hud","arabicName":"هود","englishName":"Hud","audioUrl":"https://server8.mp3quran.net/afs/011.mp3"},
      {"id":12,"name":"Yusuf","arabicName":"يوسف","englishName":"Joseph","audioUrl":"https://server8.mp3quran.net/afs/012.mp3"},
      {"id":13,"name":"Ar-Ra'd","arabicName":"الرعد","englishName":"The Thunder","audioUrl":"https://server8.mp3quran.net/afs/013.mp3"},
      {"id":14,"name":"Ibrahim","arabicName":"إبراهيم","englishName":"Abraham","audioUrl":"https://server8.mp3quran.net/afs/014.mp3"},
      {"id":15,"name":"Al-Hijr","arabicName":"الحجر","englishName":"The Rock","audioUrl":"https://server8.mp3quran.net/afs/015.mp3"},
      {"id":16,"name":"An-Nahl","arabicName":"النحل","englishName":"The Bee","audioUrl":"https://server8.mp3quran.net/afs/016.mp3"},
      {"id":17,"name":"Al-Isra","arabicName":"الإسراء","englishName":"The Night Journey","audioUrl":"https://server8.mp3quran.net/afs/017.mp3"},
      {"id":18,"name":"Al-Kahf","arabicName":"الكهف","englishName":"The Cave","audioUrl":"https://server8.mp3quran.net/afs/018.mp3"},
      {"id":19,"name":"Maryam","arabicName":"مريم","englishName":"Mary","audioUrl":"https://server8.mp3quran.net/afs/019.mp3"},
      {"id":20,"name":"Taha","arabicName":"طه","englishName":"Ta-Ha","audioUrl":"https://server8.mp3quran.net/afs/020.mp3"},
      {"id":21,"name":"Al-Anbiya","arabicName":"الأنبياء","englishName":"The Prophets","audioUrl":"https://server8.mp3quran.net/afs/021.mp3"},
      {"id":22,"name":"Al-Hajj","arabicName":"الحج","englishName":"The Pilgrimage","audioUrl":"https://server8.mp3quran.net/afs/022.mp3"},
      {"id":23,"name":"Al-Mu'minun","arabicName":"المؤمنون","englishName":"The Believers","audioUrl":"https://server8.mp3quran.net/afs/023.mp3"},
      {"id":24,"name":"An-Nur","arabicName":"النور","englishName":"The Light","audioUrl":"https://server8.mp3quran.net/afs/024.mp3"},
      {"id":25,"name":"Al-Furqan","arabicName":"الفرقان","englishName":"The Criterion","audioUrl":"https://server8.mp3quran.net/afs/025.mp3"},
      {"id":26,"name":"Ash-Shu'ara","arabicName":"الشعراء","englishName":"The Poets","audioUrl":"https://server8.mp3quran.net/afs/026.mp3"},
      {"id":27,"name":"An-Naml","arabicName":"النمل","englishName":"The Ant","audioUrl":"https://server8.mp3quran.net/afs/027.mp3"},
      {"id":28,"name":"Al-Qasas","arabicName":"القصص","englishName":"The Stories","audioUrl":"https://server8.mp3quran.net/afs/028.mp3"},
      {"id":29,"name":"Al-Ankabut","arabicName":"العنكبوت","englishName":"The Spider","audioUrl":"https://server8.mp3quran.net/afs/029.mp3"},
      {"id":30,"name":"Ar-Rum","arabicName":"الروم","englishName":"The Romans","audioUrl":"https://server8.mp3quran.net/afs/030.mp3"},
      {"id":31,"name":"Luqman","arabicName":"لقمان","englishName":"Luqman","audioUrl":"https://server8.mp3quran.net/afs/031.mp3"},
      {"id":32,"name":"As-Sajda","arabicName":"السجدة","englishName":"The Prostration","audioUrl":"https://server8.mp3quran.net/afs/032.mp3"},
      {"id":33,"name":"Al-Ahzab","arabicName":"الأحزاب","englishName":"The Combined Forces","audioUrl":"https://server8.mp3quran.net/afs/033.mp3"},
      {"id":34,"name":"Saba","arabicName":"سبإ","englishName":"Sheba","audioUrl":"https://server8.mp3quran.net/afs/034.mp3"},
      {"id":35,"name":"Fatir","arabicName":"فاطر","englishName":"The Originator","audioUrl":"https://server8.mp3quran.net/afs/035.mp3"},
      {"id":36,"name":"Ya-Sin","arabicName":"يس","englishName":"Ya Sin","audioUrl":"https://server8.mp3quran.net/afs/036.mp3"},
      {"id":37,"name":"As-Saffat","arabicName":"الصافات","englishName":"Those who set the Ranks","audioUrl":"https://server8.mp3quran.net/afs/037.mp3"},
      {"id":38,"name":"Sad","arabicName":"ص","englishName":"The Letter Saad","audioUrl":"https://server8.mp3quran.net/afs/038.mp3"},
      {"id":39,"name":"Az-Zumar","arabicName":"الزمر","englishName":"The Groups","audioUrl":"https://server8.mp3quran.net/afs/039.mp3"},
      {"id":40,"name":"Ghafir","arabicName":"غافر","englishName":"The Forgiver","audioUrl":"https://server8.mp3quran.net/afs/040.mp3"},
      {"id":41,"name":"Fussilat","arabicName":"فصلت","englishName":"Explained in Detail","audioUrl":"https://server8.mp3quran.net/afs/041.mp3"},
      {"id":42,"name":"Ash-Shura","arabicName":"الشورى","englishName":"The Consultation","audioUrl":"https://server8.mp3quran.net/afs/042.mp3"},
      {"id":43,"name":"Az-Zukhruf","arabicName":"الزخرف","englishName":"The Ornaments of Gold","audioUrl":"https://server8.mp3quran.net/afs/043.mp3"},
      {"id":44,"name":"Ad-Dukhan","arabicName":"الدخان","englishName":"The Smoke","audioUrl":"https://server8.mp3quran.net/afs/044.mp3"},
      {"id":45,"name":"Al-Jathiya","arabicName":"الجاثية","englishName":"The Kneeling","audioUrl":"https://server8.mp3quran.net/afs/045.mp3"},
      {"id":46,"name":"Al-Ahqaf","arabicName":"الأحقاف","englishName":"The Dunes","audioUrl":"https://server8.mp3quran.net/afs/046.mp3"},
      {"id":47,"name":"Muhammad","arabicName":"محمد","englishName":"Muhammad","audioUrl":"https://server8.mp3quran.net/afs/047.mp3"},
      {"id":48,"name":"Al-Fath","arabicName":"الفتح","englishName":"The Victory","audioUrl":"https://server8.mp3quran.net/afs/048.mp3"},
      {"id":49,"name":"Al-Hujurat","arabicName":"الحجرات","englishName":"The Rooms","audioUrl":"https://server8.mp3quran.net/afs/049.mp3"},
      {"id":50,"name":"Qaf","arabicName":"ق","englishName":"The Letter Qaf","audioUrl":"https://server8.mp3quran.net/afs/050.mp3"},
      {"id":51,"name":"Adh-Dhariyat","arabicName":"الذاريات","englishName":"The Winnowing Winds","audioUrl":"https://server8.mp3quran.net/afs/051.mp3"},
      {"id":52,"name":"At-Tur","arabicName":"الطور","englishName":"The Mount","audioUrl":"https://server8.mp3quran.net/afs/052.mp3"},
      {"id":53,"name":"An-Najm","arabicName":"النجم","englishName":"The Star","audioUrl":"https://server8.mp3quran.net/afs/053.mp3"},
      {"id":54,"name":"Al-Qamar","arabicName":"القمر","englishName":"The Moon","audioUrl":"https://server8.mp3quran.net/afs/054.mp3"},
      {"id":55,"name":"Ar-Rahman","arabicName":"الرحمن","englishName":"The Beneficent","audioUrl":"https://server8.mp3quran.net/afs/055.mp3"},
      {"id":56,"name":"Al-Waqi'a","arabicName":"الواقعة","englishName":"The Inevitable","audioUrl":"https://server8.mp3quran.net/afs/056.mp3"},
      {"id":57,"name":"Al-Hadid","arabicName":"الحديد","englishName":"The Iron","audioUrl":"https://server8.mp3quran.net/afs/057.mp3"},
      {"id":58,"name":"Al-Mujadila","arabicName":"المجادلة","englishName":"The Pleading Woman","audioUrl":"https://server8.mp3quran.net/afs/058.mp3"},
      {"id":59,"name":"Al-Hashr","arabicName":"الحشر","englishName":"The Exile","audioUrl":"https://server8.mp3quran.net/afs/059.mp3"},
      {"id":60,"name":"Al-Mumtahana","arabicName":"الممتحنة","englishName":"She that is to be examined","audioUrl":"https://server8.mp3quran.net/afs/060.mp3"},
      {"id":61,"name":"As-Saff","arabicName":"الصف","englishName":"The Ranks","audioUrl":"https://server8.mp3quran.net/afs/061.mp3"},
      {"id":62,"name":"Al-Jumu'a","arabicName":"الجمعة","englishName":"Friday","audioUrl":"https://server8.mp3quran.net/afs/062.mp3"},
      {"id":63,"name":"Al-Munafiqun","arabicName":"المنافقون","englishName":"The Hypocrites","audioUrl":"https://server8.mp3quran.net/afs/063.mp3"},
      {"id":64,"name":"At-Taghabun","arabicName":"التغابن","englishName":"The Mutual Disillusion","audioUrl":"https://server8.mp3quran.net/afs/064.mp3"},
      {"id":65,"name":"At-Talaq","arabicName":"الطلاق","englishName":"The Divorce","audioUrl":"https://server8.mp3quran.net/afs/065.mp3"},
      {"id":66,"name":"At-Tahrim","arabicName":"التحريم","englishName":"The Prohibition","audioUrl":"https://server8.mp3quran.net/afs/066.mp3"},
      {"id":67,"name":"Al-Mulk","arabicName":"الملك","englishName":"The Sovereignty","audioUrl":"https://server8.mp3quran.net/afs/067.mp3"},
      {"id":68,"name":"Al-Qalam","arabicName":"القلم","englishName":"The Pen","audioUrl":"https://server8.mp3quran.net/afs/068.mp3"},
      {"id":69,"name":"Al-Haqqa","arabicName":"الحاقة","englishName":"The Reality","audioUrl":"https://server8.mp3quran.net/afs/069.mp3"},
      {"id":70,"name":"Al-Ma'arij","arabicName":"المعارج","englishName":"The Ascending Stairways","audioUrl":"https://server8.mp3quran.net/afs/070.mp3"},
      {"id":71,"name":"Nuh","arabicName":"نوح","englishName":"Noah","audioUrl":"https://server8.mp3quran.net/afs/071.mp3"},
      {"id":72,"name":"Al-Jinn","arabicName":"الجن","englishName":"The Jinn","audioUrl":"https://server8.mp3quran.net/afs/072.mp3"},
      {"id":73,"name":"Al-Muzzammil","arabicName":"المزمل","englishName":"The Enshrouded One","audioUrl":"https://server8.mp3quran.net/afs/073.mp3"},
      {"id":74,"name":"Al-Muddathir","arabicName":"المدثر","englishName":"The Cloaked One","audioUrl":"https://server8.mp3quran.net/afs/074.mp3"},
      {"id":75,"name":"Al-Qiyama","arabicName":"القيامة","englishName":"The Resurrection","audioUrl":"https://server8.mp3quran.net/afs/075.mp3"},
      {"id":76,"name":"Al-Insan","arabicName":"الإنسان","englishName":"Man","audioUrl":"https://server8.mp3quran.net/afs/076.mp3"},
      {"id":77,"name":"Al-Mursalat","arabicName":"المرسلات","englishName":"The Emissaries","audioUrl":"https://server8.mp3quran.net/afs/077.mp3"},
      {"id":78,"name":"An-Naba","arabicName":"النبأ","englishName":"The Announcement","audioUrl":"https://server8.mp3quran.net/afs/078.mp3"},
      {"id":79,"name":"An-Nazi'at","arabicName":"النازعات","englishName":"Those who drag forth","audioUrl":"https://server8.mp3quran.net/afs/079.mp3"},
      {"id":80,"name":"Abasa","arabicName":"عبس","englishName":"He frowned","audioUrl":"https://server8.mp3quran.net/afs/080.mp3"},
      {"id":81,"name":"At-Takwir","arabicName":"التكوير","englishName":"The Overthrowing","audioUrl":"https://server8.mp3quran.net/afs/081.mp3"},
      {"id":82,"name":"Al-Infitar","arabicName":"الإنفطار","englishName":"The Cleaving","audioUrl":"https://server8.mp3quran.net/afs/082.mp3"},
      {"id":83,"name":"Al-Mutaffifin","arabicName":"المطففين","englishName":"Defrauding","audioUrl":"https://server8.mp3quran.net/afs/083.mp3"},
      {"id":84,"name":"Al-Inshiqaq","arabicName":"الإنشقاق","englishName":"The Splitting Open","audioUrl":"https://server8.mp3quran.net/afs/084.mp3"},
      {"id":85,"name":"Al-Buruj","arabicName":"البروج","englishName":"The Constellations","audioUrl":"https://server8.mp3quran.net/afs/085.mp3"},
      {"id":86,"name":"At-Tariq","arabicName":"الطارق","englishName":"The Morning Star","audioUrl":"https://server8.mp3quran.net/afs/086.mp3"},
      {"id":87,"name":"Al-A'la","arabicName":"الأعلى","englishName":"The Most High","audioUrl":"https://server8.mp3quran.net/afs/087.mp3"},
      {"id":88,"name":"Al-Ghashiya","arabicName":"الغاشية","englishName":"The Overwhelming","audioUrl":"https://server8.mp3quran.net/afs/088.mp3"},
      {"id":89,"name":"Al-Fajr","arabicName":"الفجر","englishName":"The Dawn","audioUrl":"https://server8.mp3quran.net/afs/089.mp3"},
      {"id":90,"name":"Al-Balad","arabicName":"البلد","englishName":"The City","audioUrl":"https://server8.mp3quran.net/afs/090.mp3"},
      {"id":91,"name":"Ash-Shams","arabicName":"الشمس","englishName":"The Sun","audioUrl":"https://server8.mp3quran.net/afs/091.mp3"},
      {"id":92,"name":"Al-Lail","arabicName":"الليل","englishName":"The Night","audioUrl":"https://server8.mp3quran.net/afs/092.mp3"},
      {"id":93,"name":"Ad-Duha","arabicName":"الضحى","englishName":"The Morning Hours","audioUrl":"https://server8.mp3quran.net/afs/093.mp3"},
      {"id":94,"name":"Ash-Sharh","arabicName":"الشرح","englishName":"The Relief","audioUrl":"https://server8.mp3quran.net/afs/094.mp3"},
      {"id":95,"name":"At-Tin","arabicName":"التين","englishName":"The Fig","audioUrl":"https://server8.mp3quran.net/afs/095.mp3"},
      {"id":96,"name":"Al-Alaq","arabicName":"العلق","englishName":"The Clot","audioUrl":"https://server8.mp3quran.net/afs/096.mp3"},
      {"id":97,"name":"Al-Qadr","arabicName":"القدر","englishName":"The Power","audioUrl":"https://server8.mp3quran.net/afs/097.mp3"},
      {"id":98,"name":"Al-Bayyina","arabicName":"البينة","englishName":"The Clear Proof","audioUrl":"https://server8.mp3quran.net/afs/098.mp3"},
      {"id":99,"name":"Az-Zalzala","arabicName":"الزلزلة","englishName":"The Earthquake","audioUrl":"https://server8.mp3quran.net/afs/099.mp3"},
      {"id":100,"name":"Al-Adiyat","arabicName":"العاديات","englishName":"The Chargers","audioUrl":"https://server8.mp3quran.net/afs/100.mp3"},
      {"id":101,"name":"Al-Qari'a","arabicName":"القارعة","englishName":"The Calamity","audioUrl":"https://server8.mp3quran.net/afs/101.mp3"},
      {"id":102,"name":"At-Takathur","arabicName":"التكاثر","englishName":"The Rivalry in world increase","audioUrl":"https://server8.mp3quran.net/afs/102.mp3"},
      {"id":103,"name":"Al-Asr","arabicName":"العصر","englishName":"The Declining Day","audioUrl":"https://server8.mp3quran.net/afs/103.mp3"},
      {"id":104,"name":"Al-Humaza","arabicName":"الهمزة","englishName":"The Traducer","audioUrl":"https://server8.mp3quran.net/afs/104.mp3"},
      {"id":105,"name":"Al-Fil","arabicName":"الفيل","englishName":"The Elephant","audioUrl":"https://server8.mp3quran.net/afs/105.mp3"},
      {"id":106,"name":"Quraish","arabicName":"قريش","englishName":"Quraysh","audioUrl":"https://server8.mp3quran.net/afs/106.mp3"},
      {"id":107,"name":"Al-Ma'un","arabicName":"الماعون","englishName":"The Small kindnesses","audioUrl":"https://server8.mp3quran.net/afs/107.mp3"},
      {"id":108,"name":"Al-Kawthar","arabicName":"الكوثر","englishName":"The Abundance","audioUrl":"https://server8.mp3quran.net/afs/108.mp3"},
      {"id":109,"name":"Al-Kafirun","arabicName":"الكافرون","englishName":"The Disbelievers","audioUrl":"https://server8.mp3quran.net/afs/109.mp3"},
      {"id":110,"name":"An-Nasr","arabicName":"النصر","englishName":"The Divine Support","audioUrl":"https://server8.mp3quran.net/afs/110.mp3"},
      {"id":111,"name":"Al-Masad","arabicName":"المسد","englishName":"The Palm Fiber","audioUrl":"https://server8.mp3quran.net/afs/111.mp3"},
      {"id":112,"name":"Al-Ikhlas","arabicName":"الإخلاص","englishName":"The Sincerity","audioUrl":"https://server8.mp3quran.net/afs/112.mp3"},
      {"id":113,"name":"Al-Falaq","arabicName":"الفلق","englishName":"The Daybreak","audioUrl":"https://server8.mp3quran.net/afs/113.mp3"},
      {"id":114,"name":"An-Nas","arabicName":"الناس","englishName":"Mankind","audioUrl":"https://server8.mp3quran.net/afs/114.mp3"}
    ]
    ''';

    setState(() {
      _surahs = (json.decode(jsonData) as List).map((data) => Surah.fromJson(data)).toList();
      _filteredSurahs = _surahs;
      _isLoading = false;
    });
  }

  Future<void> _togglePlayPause(Surah surah) async {
    try {
      if (_currentlyPlayingId == surah.id && _isPlaying) {
        await _audioPlayer.pause();
        setState(() {
          _isPlaying = false;
        });
      } else {
        if (_currentlyPlayingId != surah.id) {
          await _audioPlayer.stop();
          await _audioPlayer.play(UrlSource(surah.audioUrl));
        } else {
          await _audioPlayer.resume();
        }
        setState(() {
          _currentlyPlayingId = surah.id;
          _isPlaying = true;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Playback error: ${e.toString()}'))
      );
    }
  }

  void _searchSurah(String query) {
    setState(() {
      searchText = query;
      if (query.isEmpty) {
        _filteredSurahs = _surahs;
      } else {
        _filteredSurahs = _surahs.where((surah) =>
          surah.name.toLowerCase().contains(query.toLowerCase()) ||
          surah.englishName.toLowerCase().contains(query.toLowerCase()) ||
          surah.arabicName.contains(query) ||
          surah.id.toString().contains(query)
        ).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quran App'),
        actions: [
          if (_currentlyPlayingId != null)
            IconButton(
              icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
              onPressed: () {
                if (_currentlyPlayingId != null) {
                  final currentSurah = _surahs.firstWhere(
                    (s) => s.id == _currentlyPlayingId);
                  _togglePlayPause(currentSurah);
                }
              },
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search by name, number or translation...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
              ),
              onChanged: _searchSurah,
            ),
          ),
          if (_isLoading)
            const Expanded(
              child: Center(
                child: CircularProgressIndicator(),
              ),
            )
          else
            Expanded(
              child: ListView.builder(
                itemCount: _filteredSurahs.length,
                itemBuilder: (context, index) {
                  final surah = _filteredSurahs[index];
                  final isCurrent = _currentlyPlayingId == surah.id;
                  return Card(
                    margin: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 4,
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Text(surah.id.toString()),
                      ),
                      title: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(surah.name,
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text(surah.englishName,
                            style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                      subtitle: Text(surah.arabicName,
                        style: const TextStyle(
                          fontSize: 18,
                          fontFamily: 'UthmanicHafs'
                        ),
                      ),
                      trailing: IconButton(
                        icon: Icon(
                          isCurrent && _isPlaying
                              ? Icons.pause
                              : Icons.play_arrow,
                          color: Colors.green,
                        ),
                        onPressed: () => _togglePlayPause(surah),
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}